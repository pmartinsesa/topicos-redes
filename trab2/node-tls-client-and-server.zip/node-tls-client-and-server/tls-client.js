const tls = require("tls");
const fs = require("fs");
const https = require("https");
const axios = require("axios");
const asciify = require("asciify-image");
const readline = require("readline");

const imageOptions = {
  fit: "box",
  width: 50,
  height: 50,
};

const bhImage = fs.readFileSync("./tls-cer/Images/fodase.png");
const gabigolImage = fs.readFileSync("./tls-cer/Images/gabigol.jpg");
const arrascaImage = fs.readFileSync("./tls-cer/Images/arraxca.jpg");
const imperadorImage = fs.readFileSync("./tls-cer/Images/imperador.jpg");
const obinaImage = fs.readFileSync("./tls-cer/Images/obina.png");

const options = {
  key: fs.readFileSync("./tls-cer/server-key.pem"),
  cert: fs.readFileSync("./tls-cer/server-crt.pem"),
  ca: fs.readFileSync("./tls-cer/ca-crt.pem"),
  host: "localhost",
  port: 9443,
  rejectUnauthorized: true,
  requestCert: true,
};

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

let answer = rl.question("Qual o seu nome? ", (answer) => {
  // TODO: Log the answer in a database
  console.log(`Thank you for your valuable feedback: ${answer}`);

  return answer;
  rl.close();
});


console.log(answer)

// const socket = tls.connect(options, () => {
//   console.log(
//     "client connected",
//     socket.authorized ? "authorized" : "unauthorized"
//   );
//   process.stdin.pipe(socket); //point to socket
//   process.stdin.resume(); //Begin reading from stdin so the process does not exit.
// });

// socket.setEncoding("utf8");

// socket.on("secureConnect", (data) => {
//   response = sendMessage().then((response) => {
//     console.log(response.data);

//     asciify(obinaImage, imageOptions, function (err, asciified) {
//       if (err) throw err;

//       // Print to console
//       console.log(asciified);
//     });

//     return response.data;
//   });

// });

// socket.on("data", (data) => {
//   console.log("datastage");
//   console.log(data);
// });

// socket.on("error", (error) => {
//   console.log("errorstage");
//   console.log(error);
// });

// socket.on("end", (data) => {
//   console.log("endstage");
//   console.log("Socket end event");
// });

// async function sendMessage() {
//   const httpsAgent = new https.Agent(options);

//   let x = {
//     nome: "s",
//     idade: "s",
//     peso: "s",
//     altura: "s",
//   };
//   try {
//     return await axios.post("https://localhost:9443/flamengo", x, {
//       httpsAgent,
//     });
//   } catch (error) {
//     console.log(error);
//     console.log("DEU ERRO");
//   }
// }
